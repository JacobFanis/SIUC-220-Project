
public class hashEntry<K,V> {
	K key;
	V value;
	hashEntry<K, V> next;
	
	public hashEntry(K key, V value, hashEntry<K, V> next) {
        this.key = key;
        this.value = value;
        this.next = next;
    }
}
