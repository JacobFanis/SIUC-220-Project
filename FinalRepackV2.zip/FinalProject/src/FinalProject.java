import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.Character.UnicodeBlock;
import java.net.MalformedURLException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.eclipse.jetty.util.StringUtil;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlAnchor;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.html.HtmlSpan;

//FINISH DLINKED LIST - MUST BE CAPABLE OF REFERENCING CORRECTLY


public class FinalProject<T> {
	public static HashMap<String, Object> words = new HashMap<>();
	//public static HashMap<Integer, FinalProject.DLinkedList> words = new HashMap<>();
	//public static HashMap<String, Object> jpWords = new HashMap<>();
	//public static HashMap<String, Object> prWords = new HashMap<>();
	public static DLinkedList core = new DLinkedList();
	
	// This is main, its practically unused only pointing to the WGui class to start. Kept seperate to avoid confusion, this class does all of the labor, Wgui creates the gui, Controller handles the gui transitions and effects, word is the word object.
	public static void main(String[] args) throws FailingHttpStatusCodeException, MalformedURLException, IOException {
		FinalProjectWGUI.main(args);
	}
	//Displays everything, still uses equals signs. Could use a substring to remove the equals and things prior to the equals sign but I kind of like the look of it.
public static String displayAll() {
		return words.toString() + words.size() + " words in total";
	}
	// deletes a string from the words hashmap
	public static String deletion(String engWord) {
		if(words.containsKey(engWord)) {
			words.remove(engWord);
			return "Success!, removed " + engWord;
		}else {
			return("Sorry, " + engWord + " could not be found.");
		}
		
	}
	//this method populates words or possibly the linked list using a prebuilt text file from the webscraper. Makes the process a lot smoother
public static void reader() {
		String path = System.getProperty("user.dir") + "\\tempText.txt";
		File file = new File(path);
		int lineNumber = 0;
		//words.put(0, core);
		try {
			BufferedReader bReader = new BufferedReader(new FileReader(file));
			 String disp; 
			 disp = bReader.readLine();
			  while (disp != null) {
			    word wordSet = new word(null, null, null, null, null, null, null);
			    if(disp.contains("English")) {
			    	disp = disp.replace(" English", "");
			    	wordSet.setEngWord(disp);
					disp = bReader.readLine();
					lineNumber++;
					System.out.println(lineNumber);
			    }else {disp = bReader.readLine();}
				if(disp.contains("Japanese")) {
					disp = disp.replace(" Japanese", "");
					wordSet.setJpWord(disp);
					disp = bReader.readLine();
					lineNumber++;
					System.out.println(lineNumber);
				}else {disp = bReader.readLine();}
				if(disp.contains("Pronunciation")) {
					disp = disp.replace(" Pronunciation", "");
					wordSet.setPron(disp);
					disp = bReader.readLine();
					lineNumber++;
					System.out.println(lineNumber);
				}else {disp = bReader.readLine();}
				if(disp.contains("Kanji")) {
					disp = disp.replace(" Kanji", "");
					wordSet.setKanji(disp);
					disp = bReader.readLine();
					lineNumber++;
					System.out.println(lineNumber);
				}else {disp = bReader.readLine();}
				if(disp.contains("Type")) {
					disp = disp.replace(" Type", "");
					wordSet.setVerbType(disp);
					disp = bReader.readLine();
					lineNumber++;
					System.out.println(lineNumber);
				}else {disp = bReader.readLine();}
				if(disp.contains("Conjugation")) {
					disp = disp.replace(" Conjugation", "");
					wordSet.setConj(disp);
					disp = bReader.readLine();
					lineNumber++;
					System.out.println(lineNumber);
				}else {disp = bReader.readLine();}
				if(disp.contains("Definition")) {
					disp = disp.replace(" Definition", "");
					wordSet.setDefinition(disp);
					disp = bReader.readLine();
					lineNumber++;
					System.out.println(lineNumber);
				}else {disp = bReader.readLine();}
				if(StringUtil.isBlank(wordSet.getDefinition()) == false || StringUtil.isBlank(wordSet.getJpWord()) == false || StringUtil.isBlank(wordSet.getEngWord()) == false || StringUtil.isBlank(wordSet.getKanji()) == false || StringUtil.isBlank(wordSet.getPron()) == false || StringUtil.isBlank(wordSet.getConj()) == false || StringUtil.isBlank(wordSet.getVerbType()) == false)
				words.put(wordSet.getEngWord(), wordSet);
				//core.add(wordSet);
			  } 
			  bReader.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void insertion(String engWord, String definition, String japWord, String verbType, String conj, String pron, String kanji) {
		word inputWord = new word(engWord, definition, japWord, verbType, conj, pron, kanji);
		words.put(inputWord.getEngWord(), inputWord);
	}
	//quick search method just searches by the input string allowing only english searches, may be changed to allow japanese or pronunciation searches in time.
public static String search(String choiceString) {
		if(words.containsKey(choiceString)) {
			return(words.get(choiceString).toString());
		}else {
			return("Sorry, " + choiceString + " could not be found.");
		}
	}
	//50 if else statements. This is the conjugator, it conjugates whatever word comes in based on its input variable type using the standards that jisho.org uses. Does not account for all conjugation as thats practically impossible.
	public static String conjugator(String inputType, String inputWord) {
		if(inputWord == null) {
			return "I'm sorry, I could not detect the verb type for this word!";
		}
		if(inputType.contains("suru verb")) {
			inputWord = String.format("%1$swaseru, %1$sshimasu, %1$site, %1$sshinai, %1$sshita, %1$sshimashita, %1$sshinakatta, %1$sshimasen deshita", inputWord);
			return inputWord;
		}else if(inputType.contains("ichidan verb")){
			inputWord = String.format("%1$skosaseru, %1$smasu, %1$smasen, %1$snai, %1$sta, %1$smashita, %1$smasen deshita", inputWord);
			return inputWord;
		}else if(inputType.contains("godan verb with ru ending")) {
			inputWord = String.format("%1$sraseru, %1$sshimasu, %1$stte, %1$sranai, %1$simasu, %1$smashita, %1$smasen deshita", inputWord);
			return inputWord;
		}else if(inputType.contains("godan verb with mu ending")) {
			inputWord = String.format("%1$smaseru, %1$sshimasu, %1$snde, %1$smanai, %1$simasu, %1$smashita, %1$smasen deshita", inputWord);
			return inputWord;
		}else if(inputType.contains("godan verb - iku/yuku special class")) {
			inputWord = String.format("%1$sisaseru, %1$sshimasu, %1$site, %1$sshinai, %1$smasu, %1$smashita, %1$smasen deshita", inputWord);
			return inputWord;
		}else if(inputType.contains("godan verb with bu ending")) {
			inputWord = String.format("%1$sbaseru, %1$sshimasu, %1$snde, %1$sbanai, %1$simasu, %1$smashita, %1$smasen deshita", inputWord);
			return inputWord;
		}else if(inputType.contains("godan verb with ku ending")) {
			inputWord = String.format("%1$skaseru, %1$sshimasu, %1$site, %1$skanai, %1$simasu, %1$smashita, %1$smasen deshita", inputWord);
			return inputWord;
		}else if(inputType.contains("godan verb with u ending")) {
			inputWord = String.format("%1$swaseru, %1$sshimasu, %1$stte, %1$swanai, %1$simasu, %1$smashita, %1$smasen deshita", inputWord);
			return inputWord;
		}else if(inputType.contains("godan verb with gu ending")) {
			inputWord = String.format("%1$sgaseru, %1$sshimasu, %1$side, %1$sganai, %1$simasu, %1$smashita, %1$smasen deshita", inputWord);
			return inputWord;
		}else if(inputType.contains("godan verb with nu ending")) {
			inputWord = String.format("%1$snaseru, %1$sshimasu, %1$snde, %1$snanai, %1$simasu, %1$smashita, %1$smasen deshita", inputWord);
			return inputWord;
		}else if(inputType.contains("godan verb with ru ending (irregular verb)")) {
			inputWord = String.format("%1$ssuru, %1$sshimasu, %1$site, %1$sranai, %1$simasu, %1$smashita, %1$smasen deshita", inputWord);
			return inputWord;
		}else if(inputType.contains("godan verb with su ending")) {
			inputWord = String.format("%1$ssaseru, %1$sshimasu, %1$sshite, %1$ssanai, %1$simasu, %1$smashita, %1$smasen deshita", inputWord);
			return inputWord;
		}else if(inputType.contains("godan verb with tsu ending")) {
			inputWord = String.format("%1$staseru, %1$sshimasu, %1$stte, %1$stanai, %1$simasu, %1$smashita, %1$smasen deshita", inputWord);
			return inputWord;
		}else if(inputType.contains("suru verb - irregular")) {
			inputWord = String.format("%1$ssaseru, %1$sshimasu, %1$sitte, %1$sshinai, %1$simasu, %1$smashita, %1$smasen deshita", inputWord);
			return inputWord;
		}else{
			inputWord = String.format("%1$sdatta, %1$sjanakatta, %1$sda, %1$sjanai", inputWord);
			return inputWord;
		}
	}
	//446 if else statements. This is the pronunciation builder, it takes a japanese string and converts it to english characters. It should account for all possibilities.
	public static String pronunciation(String spnTempKanji, String spnTemp) {
		String spnPron = "0" + spnTemp + "0";
		String spnWord = "0" + spnTempKanji + "0";
		String outWord = "";
		boolean flag = false;
		int j = 0;
		for(int i = 1; i != (spnWord.length()); i++) {
			//Checks for compound letters first
			if(spnWord.charAt(i) == 'き' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"kya";
			}else if(spnWord.charAt(i) == 'し' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"sha";
			}else if(spnWord.charAt(i) == 'ち' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"cha";
			}else if(spnWord.charAt(i) == 'に' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"nya";
			}else if(spnWord.charAt(i) == 'ひ' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"hya";
			}else if(spnWord.charAt(i) == 'み' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"mya";
			}else if(spnWord.charAt(i) == 'り' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"rya";
			}else if(spnWord.charAt(i) == 'き' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"kyu";
			}else if(spnWord.charAt(i) == 'し' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"shu";
			}else if(spnWord.charAt(i) == 'ち' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"chu";
			}else if(spnWord.charAt(i) == 'に' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"nyu";
			}else if(spnWord.charAt(i) == 'ひ' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"hyu";
			}else if(spnWord.charAt(i) == 'み' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"myu";
			}else if(spnWord.charAt(i) == 'り' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"ryu";
			}else if(spnWord.charAt(i) == 'き' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"kyo";
			}else if(spnWord.charAt(i) == 'し' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"sho";
			}else if(spnWord.charAt(i) == 'ち' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"cho";
			}else if(spnWord.charAt(i) == 'に' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"nyo";
			}else if(spnWord.charAt(i) == 'ひ' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"hyo";
			}else if(spnWord.charAt(i) == 'み' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"myo";
			}else if(spnWord.charAt(i) == 'り' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"ryo";
			}else if(spnWord.charAt(i) == 'ぎ' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"gya";
			}else if(spnWord.charAt(i) == 'じ' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"ja";
			}else if(spnWord.charAt(i) == 'ぢ' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"ja";
			}else if(spnWord.charAt(i) == 'び' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"bya";
			}else if(spnWord.charAt(i) == 'ぴ' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"pya";
			}else if(spnWord.charAt(i) == 'ぎ' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"gyu";
			}else if(spnWord.charAt(i) == 'じ' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"ju";
			}else if(spnWord.charAt(i) == 'ぢ' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"ju";
			}else if(spnWord.charAt(i) == 'び' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"byu";
			}else if(spnWord.charAt(i) == 'ぴ' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"pyu";
			}else if(spnWord.charAt(i) == 'ぎ' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"gyo";
			}else if(spnWord.charAt(i) == 'じ' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"jo";
			}else if(spnWord.charAt(i) == 'ぢ' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"jo";
			}else if(spnWord.charAt(i) == 'び' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"byo";
			}else if(spnWord.charAt(i) == 'ぴ' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"pyo";
			//Checks if the letter preceding is a repetition letter
			}else if(spnWord.charAt(i) == 'ぢ' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"jju";
			}else if(spnWord.charAt(i) == 'び' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"bbyu";
			}else if(spnWord.charAt(i) == 'ぴ' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"ppyu";
			}else if(spnWord.charAt(i) == 'ぎ' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"ggyo";
			}else if(spnWord.charAt(i) == 'じ' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"jjo";
			}else if(spnWord.charAt(i) == 'ぢ' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"jjo";
			}else if(spnWord.charAt(i) == 'び' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"bbyo";
			}else if(spnWord.charAt(i) == 'ぴ' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"ppyo";
			}else if(spnWord.charAt(i) == 'き' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"kkya";
			}else if(spnWord.charAt(i) == 'し' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"ssha";
			}else if(spnWord.charAt(i) == 'ち' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"ccha";
			}else if(spnWord.charAt(i) == 'に' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"nnya";
			}else if(spnWord.charAt(i) == 'ひ' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"hhya";
			}else if(spnWord.charAt(i) == 'み' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"mmya";
			}else if(spnWord.charAt(i) == 'り' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"rrya";
			}else if(spnWord.charAt(i) == 'き' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"kkyu";
			}else if(spnWord.charAt(i) == 'し' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"sshu";
			}else if(spnWord.charAt(i) == 'ち' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"cchu";
			}else if(spnWord.charAt(i) == 'に' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"nnyu";
			}else if(spnWord.charAt(i) == 'ひ' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"hhyu";
			}else if(spnWord.charAt(i) == 'み' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"mmyu";
			}else if(spnWord.charAt(i) == 'り' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"rryu";
			}else if(spnWord.charAt(i) == 'き' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"kkyo";
			}else if(spnWord.charAt(i) == 'し' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"ssho";
			}else if(spnWord.charAt(i) == 'ち' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"ccho";
			}else if(spnWord.charAt(i) == 'に' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"nnyo";
			}else if(spnWord.charAt(i) == 'ひ' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"hhyo";
			}else if(spnWord.charAt(i) == 'み' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"mmyo";
			}else if(spnWord.charAt(i) == 'り' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"rryo";
			}else if(spnWord.charAt(i) == 'ぎ' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"ggya";
			}else if(spnWord.charAt(i) == 'じ' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"jja";
			}else if(spnWord.charAt(i) == 'ぢ' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"jja";
			}else if(spnWord.charAt(i) == 'び' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"bbya";
			}else if(spnWord.charAt(i) == 'ぴ' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"ppya";
			}else if(spnWord.charAt(i) == 'ぎ' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"ggyu";
			}else if(spnWord.charAt(i) == 'じ' && spnWord.charAt(i-1) == 'っ' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"jju";
			}else if(spnWord.charAt(i) == 'あ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord + "aa";
			}else if(spnWord.charAt(i) == 'い' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord + "ii";
			}else if(spnWord.charAt(i) == 'う' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord + "uu";
			}else if(spnWord.charAt(i) == 'え' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord + "ee";
			}else if(spnWord.charAt(i) == 'お' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord + "oo";
			}else if(spnWord.charAt(i) == 'か' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord + "kka";
			}else if(spnWord.charAt(i) == 'き' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"kki";
			}else if(spnWord.charAt(i) == 'く' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"kku";
			}else if(spnWord.charAt(i) == 'け' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"kke";
			}else if(spnWord.charAt(i) == 'こ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"kko";
			}else if(spnWord.charAt(i) == 'さ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"ssa";
			}else if(spnWord.charAt(i) == 'し' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"sshi";
			}else if(spnWord.charAt(i) == 'す' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"ssu";
			}else if(spnWord.charAt(i) == 'せ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"sse";
			}else if(spnWord.charAt(i) == 'そ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"sso";
			}else if(spnWord.charAt(i) == 'た' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"tta";
			}else if(spnWord.charAt(i) == 'ち' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"cchi";
			}else if(spnWord.charAt(i) == 'つ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"ttsu";
			}else if(spnWord.charAt(i) == 'て' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"tte";
			}else if(spnWord.charAt(i) == 'と' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"tto";
			}else if(spnWord.charAt(i) == 'な' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"nna";
			}else if(spnWord.charAt(i) == 'に' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"nni";
			}else if(spnWord.charAt(i) == 'ぬ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"nnu";
			}else if(spnWord.charAt(i) == 'ね' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"nne";
			}else if(spnWord.charAt(i) == 'の' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"nno";
			}else if(spnWord.charAt(i) == 'は' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"hha";
			}else if(spnWord.charAt(i) == 'ひ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"hhi";
			}else if(spnWord.charAt(i) == 'ふ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"ffu";
			}else if(spnWord.charAt(i) == 'へ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"hhe";
			}else if(spnWord.charAt(i) == 'ほ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"hho";
			}else if(spnWord.charAt(i) == 'ま' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"mma";
			}else if(spnWord.charAt(i) == 'み' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"mmi";
			}else if(spnWord.charAt(i) == 'む' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"mmu";
			}else if(spnWord.charAt(i) == 'め' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"mme";
			}else if(spnWord.charAt(i) == 'も' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"mmo";
			}else if(spnWord.charAt(i) == 'や' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"yya";
			}else if(spnWord.charAt(i) == 'ゆ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"yyu";
			}else if(spnWord.charAt(i) == 'よ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"yyo";
			}else if(spnWord.charAt(i) == 'ら' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"rra";
			}else if(spnWord.charAt(i) == 'り' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"rri";
			}else if(spnWord.charAt(i) == 'る' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"rru";
			}else if(spnWord.charAt(i) == 'れ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"rre";
			}else if(spnWord.charAt(i) == 'ろ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"rro";
			}else if(spnWord.charAt(i) == 'わ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"wwa";
			}else if(spnWord.charAt(i) == 'ゐ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"wwi";
			}else if(spnWord.charAt(i) == 'ゑ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"wwe";
			}else if(spnWord.charAt(i) == 'を' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"oo";
			}else if(spnWord.charAt(i) == 'が' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"gga";
			}else if(spnWord.charAt(i) == 'ぎ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"ggi";
			}else if(spnWord.charAt(i) == 'ぐ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"ggu";
			}else if(spnWord.charAt(i) == 'げ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"gge";
			}else if(spnWord.charAt(i) == 'ご' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"ggo";
			}else if(spnWord.charAt(i) == 'ざ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"zza";
			}else if(spnWord.charAt(i) == 'じ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"jji";
			}else if(spnWord.charAt(i) == 'ず' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"zzu";
			}else if(spnWord.charAt(i) == 'ぜ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"zze";
			}else if(spnWord.charAt(i) == 'ぞ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"zzo";
			}else if(spnWord.charAt(i) == 'だ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"dda";
			}else if(spnWord.charAt(i) == 'ぢ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"ddji";
			}else if(spnWord.charAt(i) == 'づ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"ddzu";
			}else if(spnWord.charAt(i) == 'で' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"dde";
			}else if(spnWord.charAt(i) == 'ど' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"ddo";
			}else if(spnWord.charAt(i) == 'ば' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"bba";
			}else if(spnWord.charAt(i) == 'び' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"bbi";
			}else if(spnWord.charAt(i) == 'ぶ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"bbu";
			}else if(spnWord.charAt(i) == 'べ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"bbe";
			}else if(spnWord.charAt(i) == 'ぼ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"bbo";
			}else if(spnWord.charAt(i) == 'ぱ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"ppa";
			}else if(spnWord.charAt(i) == 'ぴ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"ppi";
			}else if(spnWord.charAt(i) == 'ぷ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"ppu";
			}else if(spnWord.charAt(i) == 'ぺ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"ppe";
			}else if(spnWord.charAt(i) == 'ぽ' && spnWord.charAt(i-1) == 'っ'){
				outWord = outWord +"ppo";
			}else if(spnWord.charAt(i) == 'ん' && spnWord.charAt(i-1) == 'っ') {
				outWord = outWord +"nn";
			//Does all remaining letters possible individually.
			}else if(spnWord.charAt(i) == 'あ') {
				outWord = outWord +"a";
			}else if(spnWord.charAt(i) == 'い'){
				outWord = outWord +'i';
			}else if(spnWord.charAt(i) == 'う'){
				outWord = outWord +'u';
			}else if(spnWord.charAt(i) == 'え'){
				outWord = outWord +'e';
			}else if(spnWord.charAt(i) == 'お'){
				outWord = outWord +'o';
			}else if(spnWord.charAt(i) == 'か'){
				outWord = outWord + "ka";
			}else if(spnWord.charAt(i) == 'き'){
				outWord = outWord +"ki";
			}else if(spnWord.charAt(i) == 'く'){
				outWord = outWord +"ku";
			}else if(spnWord.charAt(i) == 'け'){
				outWord = outWord +"ke";
			}else if(spnWord.charAt(i) == 'こ'){
				outWord = outWord +"ko";
			}else if(spnWord.charAt(i) == 'さ'){
				outWord = outWord +"sa";
			}else if(spnWord.charAt(i) == 'し'){
				outWord = outWord +"shi";
			}else if(spnWord.charAt(i) == 'す'){
				outWord = outWord +"su";
			}else if(spnWord.charAt(i) == 'せ'){
				outWord = outWord +"se";
			}else if(spnWord.charAt(i) == 'そ'){
				outWord = outWord +"so";
			}else if(spnWord.charAt(i) == 'た'){
				outWord = outWord +"ta";
			}else if(spnWord.charAt(i) == 'ち'){
				outWord = outWord +"chi";
			}else if(spnWord.charAt(i) == 'つ'){
				outWord = outWord +"tsu";
			}else if(spnWord.charAt(i) == 'て'){
				outWord = outWord +"te";
			}else if(spnWord.charAt(i) == 'と'){
				outWord = outWord +"to";
			}else if(spnWord.charAt(i) == 'な'){
				outWord = outWord +"na";
			}else if(spnWord.charAt(i) == 'に'){
				outWord = outWord +"ni";
			}else if(spnWord.charAt(i) == 'ぬ'){
				outWord = outWord +"nu";
			}else if(spnWord.charAt(i) == 'ね'){
				outWord = outWord +"ne";
			}else if(spnWord.charAt(i) == 'の'){
				outWord = outWord +"no";
			}else if(spnWord.charAt(i) == 'は'){
				outWord = outWord +"ha";
			}else if(spnWord.charAt(i) == 'ひ'){
				outWord = outWord +"hi";
			}else if(spnWord.charAt(i) == 'ふ'){
				outWord = outWord +"fu";
			}else if(spnWord.charAt(i) == 'へ'){
				outWord = outWord +"he";
			}else if(spnWord.charAt(i) == 'ほ'){
				outWord = outWord +"ho";
			}else if(spnWord.charAt(i) == 'ま'){
				outWord = outWord +"ma";
			}else if(spnWord.charAt(i) == 'み'){
				outWord = outWord +"mi";
			}else if(spnWord.charAt(i) == 'む'){
				outWord = outWord +"mu";
			}else if(spnWord.charAt(i) == 'め'){
				outWord = outWord +"me";
			}else if(spnWord.charAt(i) == 'も'){
				outWord = outWord +"mo";
			}else if(spnWord.charAt(i) == 'や'){
				outWord = outWord +"ya";
			}else if(spnWord.charAt(i) == 'ゆ'){
				outWord = outWord +"yu";
			}else if(spnWord.charAt(i) == 'よ'){
				outWord = outWord +"yo";
			}else if(spnWord.charAt(i) == 'ら'){
				outWord = outWord +"ra";
			}else if(spnWord.charAt(i) == 'り'){
				outWord = outWord +"ri";
			}else if(spnWord.charAt(i) == 'る'){
				outWord = outWord +"ru";
			}else if(spnWord.charAt(i) == 'れ'){
				outWord = outWord +"re";
			}else if(spnWord.charAt(i) == 'ろ'){
				outWord = outWord +"ro";
			}else if(spnWord.charAt(i) == 'わ'){
				outWord = outWord +"wa";
			}else if(spnWord.charAt(i) == 'ゐ'){
				outWord = outWord +"wi";
			}else if(spnWord.charAt(i) == 'ゑ'){
				outWord = outWord +"we";
			}else if(spnWord.charAt(i) == 'を'){
				outWord = outWord +"o";
			}else if(spnWord.charAt(i) == 'が'){
				outWord = outWord +"ga";
			}else if(spnWord.charAt(i) == 'ぎ'){
				outWord = outWord +"gi";
			}else if(spnWord.charAt(i) == 'ぐ'){
				outWord = outWord +"gu";
			}else if(spnWord.charAt(i) == 'げ'){
				outWord = outWord +"ge";
			}else if(spnWord.charAt(i) == 'ご'){
				outWord = outWord +"go";
			}else if(spnWord.charAt(i) == 'ざ'){
				outWord = outWord +"za";
			}else if(spnWord.charAt(i) == 'じ'){
				outWord = outWord +"ji";
			}else if(spnWord.charAt(i) == 'ず'){
				outWord = outWord +"zu";
			}else if(spnWord.charAt(i) == 'ぜ'){
				outWord = outWord +"ze";
			}else if(spnWord.charAt(i) == 'ぞ'){
				outWord = outWord +"zo";
			}else if(spnWord.charAt(i) == 'だ'){
				outWord = outWord +"da";
			}else if(spnWord.charAt(i) == 'ぢ'){
				outWord = outWord +"dji";
			}else if(spnWord.charAt(i) == 'づ'){
				outWord = outWord +"dzu";
			}else if(spnWord.charAt(i) == 'で'){
				outWord = outWord +"de";
			}else if(spnWord.charAt(i) == 'ど'){
				outWord = outWord +"do";
			}else if(spnWord.charAt(i) == 'ば'){
				outWord = outWord +"ba";
			}else if(spnWord.charAt(i) == 'び'){
				outWord = outWord +"bi";
			}else if(spnWord.charAt(i) == 'ぶ'){
				outWord = outWord +"bu";
			}else if(spnWord.charAt(i) == 'べ'){
				outWord = outWord +"be";
			}else if(spnWord.charAt(i) == 'ぼ'){
				outWord = outWord +"bo";
			}else if(spnWord.charAt(i) == 'ぱ'){
				outWord = outWord +"pa";
			}else if(spnWord.charAt(i) == 'ぴ'){
				outWord = outWord +"pi";
			}else if(spnWord.charAt(i) == 'ぷ'){
				outWord = outWord +"pu";
			}else if(spnWord.charAt(i) == 'ぺ'){
				outWord = outWord +"pe";
			}else if(spnWord.charAt(i) == 'ぽ'){
				outWord = outWord +"po";
			}else if(spnWord.charAt(i) == 'ん') {
				outWord = outWord +"n";
			}else {
				if(spnPron.length() == 0 && flag == false) {
					spnWord = spnWord.replaceAll("0", "");
					spnWord = spnWord.substring(spnTemp.length());
					flag = true;
					if(spnWord.length() > 0) {
						i = 0;
						spnWord = "0" + spnWord + "0";
						continue;
					}
				}
				if(spnWord.charAt(i) == 'っ') {
					continue;
				}
				if(spnPron.length() > 0) {
				if(spnPron.charAt(j) == '0') {
					i--;
					if(j == spnPron.length()) {
						if(outWord.length() == 1) {
							j = 0;
							i++;
							continue;
						}
					}
				}
				}
				if(i != spnWord.length()) {
					if(flag == true)
						continue;
						if(spnWord.charAt(i) == spnPron.charAt(0)) {
							spnPron = spnPron.substring(1);
						}
						String x;
						if(spnPron.length() != 0) {
						x = String.valueOf(spnPron.charAt(j));
						}else {
							continue;
						}
						
						if(spnPron.length() > 1) {
						if(spnPron.charAt(j+1) == 'ょ') {
							x = x + String.valueOf(spnPron.charAt(j+1));
						}
						if(spnPron.charAt(j+1) == 'ゅ') {
							x = x + String.valueOf(spnPron.charAt(j+1));
						}
						if(spnPron.charAt(j+1) == 'ゃ') {
							x = x + String.valueOf(spnPron.charAt(j+1));
						}
						}
						if(i == 0) {
							i++;
						}
						CharSequence temp = spnWord.subSequence(0, i);
						spnWord = spnWord.substring(i);
						temp = temp + x;
						spnWord = temp + spnWord;
						j++;
						i--;
						if(spnPron.length() > 1) {
							spnPron = spnPron.substring(j);
						}else {
							spnPron = "";
						}
						j = 0;
						if(i == spnWord.length()) {
							i--;
						}
					}else {
						if(i == 0) {
							i++;
							continue;
						}
						break;
					}
			}
		}
		
		return outWord;
	}
	public static void populatingJisho() throws FailingHttpStatusCodeException, MalformedURLException, IOException {
		int inputValue = 0;
		String path = System.getProperty("user.dir") + "\\tempText.txt";
		FileWriter writer = new FileWriter(path, true);
		BufferedWriter printer = new BufferedWriter(writer);
		String url ="https://jisho.org/search/%23common";
		int innerValue = 1;
		
		try (WebClient webClient = new WebClient(BrowserVersion.CHROME);){
			
			// webClient settings being changed to minimize features, increasing iteration speed
			webClient.getOptions().setRedirectEnabled(true);
			webClient.getOptions().setCssEnabled(false);
			webClient.getOptions().setThrowExceptionOnScriptError(false);
			webClient.getOptions().setThrowExceptionOnFailingStatusCode(false);
			webClient.getOptions().setUseInsecureSSL(false);
			webClient.getOptions().setJavaScriptEnabled(false);
			webClient.getCookieManager().setCookiesEnabled(false);	
			HtmlPage basePage = webClient.getPage(url);
			
			//The item List, corresponding to every element that has a path //*[@id=\"primary\"]/div/div, in other words what i care about
			List<DomElement> items = basePage.getByXPath("//*[@id=\"primary\"]/div/div");
			if(items.isEmpty()) {
				System.out.print("The list is empty.");
			}else {
				for(int i = 0; i < inputValue; i++) {
						try {
							System.out.println(i);
							//creates new word object, and elements that will be put into word
							HtmlSpan divDefinition = null;
							word wordSet = new word(null, null, null, null, null, null, null);
							int deepValue = 1;
							String spnTemp = "";
							HtmlSpan spnWord = null;
							HtmlAnchor anchor = basePage.getFirstByXPath("//*[@id=\"primary\"]/div/div["+ innerValue +"]/a");
							HtmlPage dictPage = anchor.click();
							List<DomElement> inItems = dictPage.getByXPath("//*[@id=\"page_container\"]/div/div");
							for(DomElement domData : inItems) {
								if(domData.getFirstByXPath("//span[@class='meaning-abstract']") != null) {
									divDefinition = domData.getFirstByXPath("//span[@class='meaning-abstract']");
								}
								else {
									divDefinition = domData.getFirstByXPath("//span[@class='meaning-meaning']");
								}
								DomElement divElements = domData.getFirstByXPath("//*[@id=\"page_container\"]/div/div/article/div/div[2]/div/div[1]");
								HtmlSpan divMean = domData.getFirstByXPath("//*[@id=\"page_container\"]/div/div/article/div/div[2]/div/div[2]/div/span[2]");
								do{
									spnWord = domData.getFirstByXPath("//*[@id=\"page_container\"]/div/div/article/div/div[1]/div[1]/div/span[1]/span["+ deepValue +"]");
									spnTemp = spnTemp + spnWord.asText();
									deepValue++;
								}while(domData.getFirstByXPath("//*[@id=\"page_container\"]/div/div/article/div/div[1]/div[1]/div/span[1]/span["+ deepValue +"]") != null);
							HtmlSpan spnKanji = domData.getFirstByXPath("//*[@id=\"page_container\"]/div/div/article/div/div[1]/div[1]/div/span[2]");
							// Grammatical corrections, not paired down to increase readability
							String divMeanOut = null;
							String divDefinitionOut = null;
							if(divMean.asText().contains(";")) {
								divMeanOut = divMean.asText().substring(0, divMean.asText().indexOf(';'));
							}else {
								divMeanOut = divMean.asText();
							}
							if(divDefinition.asText().contains(".")){
								divDefinitionOut = divDefinition.asText().substring(0, divDefinition.asText().indexOf('.') + 1);
							}else {
								divDefinitionOut = divDefinition.asText();
							}	
							String spnPron = pronunciation(spnKanji.asText(), spnTemp);
							String divElementsOut = divElements.asText().toLowerCase();
							String conj = conjugator(divElementsOut, spnPron);
							// Defines all fields from the word value except conjugation
							wordSet.setVerbType(divElementsOut);
							wordSet.setDefinition(divDefinitionOut);
							wordSet.setEngWord(divMeanOut);
							wordSet.setJpWord(spnKanji.asText());
							wordSet.setPron(spnPron);
							wordSet.setKanji(spnKanji.asText());
							wordSet.setConj(conj);
							if(StringUtils.isBlank(spnPron.replace(" Pronunciation", "")) == true || StringUtils.isBlank(conj.replace(" Conjugation", "")) == true || StringUtils.isBlank(divElementsOut.replace(" Type", "")) == true || StringUtils.isBlank(divMeanOut.replace(" English", "")) == true || StringUtils.isBlank(divDefinitionOut.replace(" Definition", "")) == true) {
								System.out.println("SKIPPED " + i);
								innerValue++;
								continue;
							}
							String writtenString = "" + divMeanOut + " English\n" + spnTemp + " Japanese\n" + spnPron + " Pronunciation\n" + spnKanji.asText() + " Kanji\n" + divElementsOut + " Type\n" + conj + " Conjugation\n" + divDefinitionOut +" Definition\n";
							printer.write(writtenString);
							//words.put(divMeanOut, wordSet);
							// increases the innerValue loop variable to move onto the next html LI element
							innerValue++;
							}
						// Catches a guaranteed null pointer exception and fixes by changing inner to 1 and outer up 1, to move on to the next UL
						}catch(NullPointerException e) {
							innerValue++;
						// At end of loop, removes key that comes up as empty,
						}finally {
						if(innerValue == 20) {
							innerValue = 1;
							HtmlAnchor anchor = basePage.getFirstByXPath("//*[@id=\"primary\"]/div/a");
							basePage = anchor.click();
							items = basePage.getByXPath("//*[@id=\"primary\"]/div/div");
						}
					}
				}
				printer.close();
			}
		}
	}
// This is the start of my DLinked List, being made to populate the hashmaps with references. May be scrapped later in favor of something else.
public static class DLinkedList{
		DLNode firstNode;
		DLNode secondFirstNode;
		DLNode thirdFirstNode;
		int numberOfEntries;
		public DLinkedList() {
			firstNode = null;
			numberOfEntries = 0;
		}
		public boolean contains(String engWord) {
			// TODO Auto-generated method stub
			return false;
		}
		public boolean add(word anEntry) {
			DLNode coreNode = new DLNode(anEntry, null, null);
			DLNode pronNode = new DLNode(anEntry.getPron(), coreNode, null);
			DLNode hirNode = new DLNode(anEntry.getJpWord(), coreNode, null);
			boolean result = false;
			if(firstNode == null) {
				firstNode = coreNode;
				pronNode.prev = firstNode;
				hirNode.prev = firstNode;
				numberOfEntries++;
				result = true;
			}else {
				coreNode.next = firstNode;
				firstNode.prev = coreNode;
				firstNode = coreNode;
				secondFirstNode = pronNode;
				pronNode.next = secondFirstNode;
				secondFirstNode.prev = pronNode;
				thirdFirstNode = hirNode;
				hirNode.next = thirdFirstNode;
				thirdFirstNode.prev = hirNode;
				//prWords.put(anEntry.getPron(), pronNode);
				//jpWords.put(anEntry.getJpWord(), hirNode);
				numberOfEntries++;
				result = true;
			}
			return result;
		}
		public boolean remove() {
			boolean result = false;
			if(!isEmpty()) {
				firstNode.next = firstNode;
				firstNode.prev = null;
				result = true;
			}else {
				System.out.print("The list is empty");
			}
			return result;
		}
		public boolean remove(word anEntry) {
			boolean result = false;
			DLNode tempNode = firstNode;
			if(!isEmpty()) {
				if(firstNode.data == anEntry) {
					remove();
					result = true;
				}else{
					while(tempNode.data != anEntry) {
					tempNode = tempNode.next;
					}
					if(tempNode.data == anEntry) {
					tempNode.next = tempNode.prev;
					tempNode.prev = tempNode.next;
					tempNode = null;
					result = true;
					}else {
						System.out.print("Could not find " + anEntry);
					}
				}
			}else {
				System.out.print("The list is empty");
			}
			return result;
		}
		private boolean isEmpty() {
			return firstNode == null;
		}
		private static class DLNode{
			private word data;
			private String name;
			private DLNode next;
			private DLNode prev;
			private DLNode(word inData, DLNode next, DLNode prev) {
				this.data = inData;
				this.next = next;
				this.prev = prev;
			}
			private DLNode(String inData, DLNode core, DLNode next) {
				this.name = inData;
				this.prev = core;
				this.next = next;
			}
		}
	}
}
