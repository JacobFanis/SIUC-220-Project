import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;

import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;

import javafx.application.Platform;
import javafx.animation.FadeTransition;
import javafx.animation.ScaleTransition;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.util.Duration;

public class FinalController {
	
	TranslateTransition titleTransition = new TranslateTransition();
	TranslateTransition titleTransitionPT2 = new TranslateTransition();
	TranslateTransition leaveTitle = new TranslateTransition();
	ScaleTransition endTransition = new ScaleTransition();
	FadeTransition kanjiTransition = new FadeTransition();
	TranslateTransition moveKan = new TranslateTransition();
	//kodo o daiko! is derived from "Free to use sounds" https://freetousesounds.bandcamp.com/track/kodo-o-daiko-japanese-drums. Thanks.
	String songName = "kodoodaiko.mp3";
	//okedo-A1 and cymbal_1 are derived from SampleSwap https://sampleswap.org/filebrowser-new.php?d=DRUMS+%28FULL+KITS%29%2FETHNIC+and+WORLD+PERCUSSION%2FJapanese+Drums%2F. Thanks.
	String effectName = "okedo.wav";
	String returnName = "cymbal.aif";
	
	Media song = new Media(new File(songName).toURI().toString());
	Media effect = new Media(new File(effectName).toURI().toString());
	Media returnEffect = new Media(new File(returnName).toURI().toString());
	
	MediaPlayer songPlayer = new MediaPlayer(song);
	MediaPlayer effectPlayer = new MediaPlayer(effect);
	MediaPlayer returnPlayer = new MediaPlayer(returnEffect);
    @FXML
    private VBox displayMenu;

    @FXML
    private TextArea displayOut;

    @FXML
    private VBox insertMenu;

    @FXML
    private TextField engWord;

    @FXML
    private TextField japWord;

    @FXML
    private TextField def;

    @FXML
    private TextField verbType;

    @FXML
    private TextField conj;

    @FXML
    private TextField pron;

    @FXML
    private TextField kanji;

    @FXML
    private VBox removeMenu;

    @FXML
    private TextField removeInput;

    @FXML
    private TextField removeOut;

    @FXML
    private VBox searchMenu;

    @FXML
    private TextField searchInput;

    @FXML
    private TextArea outText;

    @FXML
    private HBox mainMenu;

    @FXML
    private Label dispKanji;

    @FXML
    private Button displayButton;

    @FXML
    private Label insKanji;

    @FXML
    private Button insertButton;

    @FXML
    private Label quitKanji;

    @FXML
    private Button quitButton;

    @FXML
    private Label searchKanji;

    @FXML
    private Button searchButton;

    @FXML
    private Label remKanji;

    @FXML
    private Button removeButton;

    @FXML
    private ToggleGroup Volume;

    @FXML
    private StackPane menuGraphics;

    @FXML
    private Rectangle flag;

    @FXML
    private VBox SmartLibBox;

    @FXML
    private VBox textBox;

    @FXML
    private Rectangle transEffect;

    @FXML
    private Button WelcomeToTitle;

    @FXML
    private Text hajime;

    @FXML
    void mainMenu(ActionEvent event) {
    	returnPlayer.play();
    	endTransition.setNode(transEffect);
		endTransition.setToY(200);
		endTransition.setDuration(Duration.seconds(1));
		endTransition.setDelay(Duration.seconds(0));
		endTransition.setCycleCount(1);
		endTransition.setAutoReverse(true);
    	endTransition.play();
    	endTransition.setOnFinished(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				endTransition.setToY(0);
				endTransition.play();
				mainMenu.setVisible(true);
				menuGraphics.setVisible(true);
				searchMenu.setVisible(false);
				insertMenu.setVisible(false);
				removeMenu.setVisible(false);
				displayMenu.setVisible(false);
				endTransition.setOnFinished(null);
			}
		});
    }
    void show() {
    	kanjiTransition.stop();
    	kanjiTransition.setDuration(Duration.seconds(3));
    	kanjiTransition.setToValue(1);
    	kanjiTransition.play();
    }
    void notShow() {
    	kanjiTransition.stop();
    	kanjiTransition.setDuration(Duration.seconds(2));
    	kanjiTransition.setToValue(0);
    	kanjiTransition.play();

    }
    
    @FXML
    void dispHoverEnd(MouseEvent event) {
    	kanjiTransition.setNode(dispKanji);
    	notShow();
    }

    @FXML
    void dispHoverStart(MouseEvent event) {
    	kanjiTransition.setNode(dispKanji);
    	show();
    }
    
    @FXML
    void quitHoverEnd(MouseEvent event) {
    	kanjiTransition.setNode(quitKanji);
    	notShow();
    }

    @FXML
    void quitHoverStart(MouseEvent event) {
    	kanjiTransition.setNode(quitKanji);
    	show();
    }
    
    @FXML
    void remHoverEnd(MouseEvent event) {
    	kanjiTransition.setNode(remKanji);
    	notShow();
    }

    @FXML
    void remHoverStart(MouseEvent event) {
    	kanjiTransition.setNode(remKanji);
    	show();
    }
    
    @FXML
    void searchHoverEnd(MouseEvent event) {
    	kanjiTransition.setNode(searchKanji);
    	notShow();
    }

    @FXML
    void searchHoverStart(MouseEvent event) {
    	kanjiTransition.setNode(searchKanji);
    	show();
    }
    
    @FXML
    void insHoverEnd(MouseEvent event) {
    	kanjiTransition.setNode(insKanji);
    	notShow();
    }

    @FXML
    void insHoverStart(MouseEvent event) {
    	kanjiTransition.setNode(insKanji);
    	show();
    }
    @FXML
    void Quit(ActionEvent event) {
    	Platform.exit();
    }
    
    @FXML
    void soundStart(ActionEvent event) {
    	songPlayer.setMute(false);
    	effectPlayer.setMute(false);
    	returnPlayer.setMute(false);
    }

    @FXML
    void soundStop(ActionEvent event) {
    	songPlayer.setMute(true);
    	effectPlayer.setMute(true);
    	returnPlayer.setMute(true);
    }
    @FXML
    void DisplayStart(ActionEvent event) {
    	effectPlayer.play();
    	endTransition.setNode(transEffect);
		endTransition.setToY(200);
		endTransition.setDuration(Duration.seconds(1));
		endTransition.setDelay(Duration.seconds(0));
		endTransition.setCycleCount(1);
		endTransition.setAutoReverse(true);
    	endTransition.play();
    	endTransition.setOnFinished(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				endTransition.setToY(0);
				endTransition.play();
				mainMenu.setVisible(false);
				menuGraphics.setVisible(false);
				displayMenu.setVisible(true);
				endTransition.setOnFinished(null);
			}
		});
    }
    
    @FXML
    void displayMethod(ActionEvent event) {
    	displayOut.setText(FinalProject.displayAll().replace("{", "").replace("}", ""));
    }
    
    @FXML
    void InsertStart(ActionEvent event) {
    	effectPlayer.play();
    	endTransition.setNode(transEffect);
		endTransition.setToY(200);
		endTransition.setDuration(Duration.seconds(1));
		endTransition.setDelay(Duration.seconds(0));
		endTransition.setCycleCount(1);
		endTransition.setAutoReverse(true);
    	endTransition.play();
    	endTransition.setOnFinished(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				endTransition.setToY(0);
				endTransition.play();
				mainMenu.setVisible(false);
				menuGraphics.setVisible(false);
				insertMenu.setVisible(true);
				endTransition.setOnFinished(null);
			}
		});
    }
    @FXML
    void InsertMethod(ActionEvent event) {
    	FinalProject.insertion(engWord.getText(), def.getText(), japWord.getText(), verbType.getText(), conj.getText(), pron.getText(), kanji.getText());
		engWord.setText("Thank you for your input!");
		def.setText("");
		japWord.setText("");
		verbType.setText("");
		conj.setText("");
		pron.setText("");
		kanji.setText("");
    }

    @FXML
    void RemoveStart(ActionEvent event) {
    	effectPlayer.play();
    	endTransition.setNode(transEffect);
		endTransition.setToY(200);
		endTransition.setDuration(Duration.seconds(1));
		endTransition.setDelay(Duration.seconds(0));
		endTransition.setCycleCount(1);
		endTransition.setAutoReverse(true);
    	endTransition.play();
    	endTransition.setOnFinished(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				endTransition.setToY(0);
				endTransition.play();
				mainMenu.setVisible(false);
				menuGraphics.setVisible(false);
				removeMenu.setVisible(true);
				endTransition.setOnFinished(null);
			}
		});
    }
    @FXML
    void removeMethod(ActionEvent event) {
    	removeOut.setText(FinalProject.deletion(removeInput.getText()));
    }
    @FXML
    void SearchStart(ActionEvent event) {
    	effectPlayer.play();
    	endTransition.setNode(transEffect);
		endTransition.setToY(200);
		endTransition.setDuration(Duration.seconds(1));
		endTransition.setDelay(Duration.seconds(0));
		endTransition.setCycleCount(1);
		endTransition.setAutoReverse(true);
    	endTransition.play();
    	endTransition.setOnFinished(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				endTransition.setToY(0);
				endTransition.play();
				mainMenu.setVisible(false);
				menuGraphics.setVisible(false);
				searchMenu.setVisible(true);
				endTransition.setOnFinished(null);
			}
		});
    }
    @FXML
    void searchMethod(ActionEvent event) {
    	outText.setText(FinalProject.search(searchInput.getText()));
    }
    @FXML
    void initialize(ActionEvent event) {
    	try {
			FinalProject.populatingJisho();
			FinalProject.reader();
		} catch (FailingHttpStatusCodeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	songPlayer.setOnEndOfMedia(new Runnable() {
			@Override
			public void run() {
				songPlayer.seek(Duration.ZERO);
				
			}
    	});
    	songPlayer.play();
    	effectPlayer.setOnEndOfMedia(new Runnable() {
			@Override
			public void run() {
				effectPlayer.seek(Duration.ZERO);
				effectPlayer.pause();
			}
    	});
    	returnPlayer.setOnEndOfMedia(new Runnable() {
			@Override
			public void run() {
				returnPlayer.seek(Duration.ZERO);
				returnPlayer.pause();
			}
    	});
    	endTransition.setNode(transEffect);
		endTransition.setToY(40);
		endTransition.setDuration(Duration.seconds(1));
		endTransition.setDelay(Duration.seconds(3));
		endTransition.setCycleCount(1);
		endTransition.setAutoReverse(true);
		titleTransition.setNode(textBox);
    	titleTransition.setDuration(Duration.seconds(1));
		titleTransition.setToY(1000);
		titleTransitionPT2.setNode(SmartLibBox);
		titleTransitionPT2.setToY(300);
		titleTransitionPT2.setDuration(Duration.seconds(1));
		titleTransition.play();
		titleTransitionPT2.play();
		moveKan.setNode(hajime);
		moveKan.setToY(1050);
		moveKan.setDelay(Duration.seconds(3));
		moveKan.setDuration(Duration.millis(670));
		moveKan.play();
		endTransition.play();
		WelcomeToTitle.setVisible(false);
		endTransition.setOnFinished(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				kanjiTransition.setNode(transEffect);
				kanjiTransition.setDuration(Duration.seconds(2));
				kanjiTransition.setToValue(0);
				kanjiTransition.play();
				textBox.setVisible(false);
				flag.setVisible(false);
				flag.setX(2000);
				flag.setY(2000);
				SmartLibBox.setVisible(false);
				endTransition.setOnFinished(null);
				kanjiTransition.setOnFinished(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent event) {
						endTransition.setDuration(Duration.seconds(1));
						endTransition.setDelay(Duration.seconds(0));
						endTransition.setToY(0);
						endTransition.play();
						kanjiTransition.setOnFinished(null);
						endTransition.setOnFinished(new EventHandler<ActionEvent>() {

							@Override
							public void handle(ActionEvent event) {
								transEffect.setOpacity(1);
								hajime.setVisible(false);
								endTransition.setOnFinished(null);
							}
							
						});
					}
					
				});
			}
		});
		event.consume();
    }

}
