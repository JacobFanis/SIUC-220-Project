import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlAnchor;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.html.HtmlSpan;

import javafx.application.Application;
//ideas
//make 26 linked lists to go into hashmaps to do more with the hashmap
//make auto conjugator
public class FinalProject {
	public static HashMap<String, Object> words = new HashMap<>();
	
	static Scanner choice = new Scanner(System.in);
	public static void main(String[] args) throws FailingHttpStatusCodeException, MalformedURLException, IOException {
		//Application.launch(Main.class);
		System.out.println("Hello, how many words would you like to load, ordered by most common first?(1000 takes 4.8 minutes~) The limit is 15000");
		String inputValue1 = choice.nextLine();
		int inputValue = Integer.parseInt(inputValue1);
		if(inputValue < 15000 && inputValue > 0) {
			long start = System.currentTimeMillis(); 
			//populatingJisho(inputValue);
			long elapsedTimeMillis = System.currentTimeMillis()-start;
			float elapsedTimeSec = elapsedTimeMillis/1000F;
			System.out.println(elapsedTimeSec);
		}else {
			System.out.println("Please input a value between 1 and 21000(1000 takes 3.5 minutes~)");
		}
		//mainMenu();
		
	}/*
	public static void mainMenu() {
		

		// this portion designates the strings used in the first print statement
		String welcome = "Welcome to the English to Japanese Dictionary\nThis program will cover only generalities, as Japanese can get incredibly in depth \nPlease make a choice from below:";
		String choices1 = "1. All current words";
		String choices2 = "2. Search";
		String choices3 = "3. Insertion";
		String choices4 = "4. Delete";
		String choices5 = "5. Exit";
		String finishLine = "Please input the number corresponding to the choice you would like to make. ";
		String choiceString;
		// said print statement
		
		//switch statement
		boolean x = false;
		while(x == false) {
			System.out.println(String.format("%s \n %s \n %s \n %s \n %s \n %s \n%s", welcome, choices1, choices2, choices3, choices4, choices5, finishLine));
			choiceString = choice.nextLine();
			if(choiceString.equals("1")) {
				System.out.println(words.keySet());
			}
			else if(choiceString.equals("2")) {
				//search();
			}
			else if(choiceString.equals("3")) {
				insertion();
			}
			else if(choiceString.equals("4")) {
				deletion();
			}
			else if(choiceString.equals("5")) {
				System.out.println("Goodbye!");
				x = true;
			}
			else {
				System.out.println("Please input a valid option (1-5)");
			}
		}
	}
	*/
	
	public static String displayAll() {
		return words.toString() + words.size() + " words in total";
	}
	
	public static String deletion(String engWord) {
		if(words.containsKey(engWord)) {
			words.remove(engWord);
			return "Success!, removed " + engWord;
		}else {
			return("Sorry, " + engWord + " could not be found.");
		}
		
	}
	public static void insertion(String engWord, String definition, String japWord, String verbType, String conj, String pron, String kanji) {
		word inputWord = new word(engWord, definition, japWord, verbType, conj, pron, kanji);
		words.put(engWord.toLowerCase(), inputWord);
	}
	public static String search(String choiceString) {
		if(words.containsKey(choiceString)) {
			return(words.get(choiceString).toString());
		}else {
			return("Sorry, " + choiceString + " could not be found.");
		}
	}
	public static String conjugator(String inputType, String inputWord) {
		if(inputWord == null) {
			return "noun";
		}
		if(inputType.contains("suru verb")) {
			inputWord = String.format("%1$s, %1$sshimasu, %1$sshimasen, %1$sshinai, %1$sshita, \n%1$sshimashita, %1$sshinakatta, %1$sshimasen deshita", inputWord);
			return inputWord;
		}else if(inputType.contains("ichidan verb")){
			inputWord = String.format("%1$sru, %1$smasu, %1$smasen, %1$snai, %1$sta, %1$smashita, %1$snakatta, %1$smasen deshita", inputWord);
			return inputWord;
		}else if(inputType.contains("godan verb with ru ending")) {
			inputWord = String.format("%1$ssuru, %1$sshimasu, %1$sshimasen, %1$sshinai, %1$sshita, %1$sshimashita, %1$sshinakatta, %1$sshimasen deshita", inputWord);
			return inputWord;
		}else if(inputType.contains("godan verb with mu ending")) {
			inputWord = String.format("%1$ssuru, %1$sshimasu, %1$sshimasen, %1$sshinai, %1$sshita, %1$sshimashita, %1$sshinakatta, %1$sshimasen deshita", inputWord);
			return inputWord;
		}else if(inputType.contains("godan verb - iku/yuku special class")) {
			inputWord = String.format("%1$ssuru, %1$sshimasu, %1$sshimasen, %1$sshinai, %1$sshita, %1$sshimashita, %1$sshinakatta, %1$sshimasen deshita", inputWord);
			return inputWord;
		}else if(inputType.contains("godan verb with bu ending")) {
			inputWord = String.format("%1$ssuru, %1$sshimasu, %1$sshimasen, %1$sshinai, %1$sshita, %1$sshimashita, %1$sshinakatta, %1$sshimasen deshita", inputWord);
			return inputWord;
		}else if(inputType.contains("godan verb with ku ending")) {
			inputWord = String.format("%1$ssuru, %1$sshimasu, %1$sshimasen, %1$sshinai, %1$sshita, %1$sshimashita, %1$sshinakatta, %1$sshimasen deshita", inputWord);
			return inputWord;
		}else if(inputType.contains("godan verb with u ending")) {
			inputWord = String.format("%1$ssuru, %1$sshimasu, %1$sshimasen, %1$sshinai, %1$sshita, %1$sshimashita, %1$sshinakatta, %1$sshimasen deshita", inputWord);
			return inputWord;
		}else if(inputType.contains("godan verb with gu ending")) {
			inputWord = String.format("%1$ssuru, %1$sshimasu, %1$sshimasen, %1$sshinai, %1$sshita, %1$sshimashita, %1$sshinakatta, %1$sshimasen deshita", inputWord);
			return inputWord;
		}else if(inputType.contains("godan verb with nu ending")) {
			inputWord = String.format("%1$ssuru, %1$sshimasu, %1$sshimasen, %1$sshinai, %1$sshita, %1$sshimashita, %1$sshinakatta, %1$sshimasen deshita", inputWord);
			return inputWord;
		}else if(inputType.contains("godan verb with ru ending (irregular verb)")) {
			inputWord = String.format("%1$ssuru, %1$sshimasu, %1$sshimasen, %1$sshinai, %1$sshita, %1$sshimashita, %1$sshinakatta, %1$sshimasen deshita", inputWord);
			return inputWord;
		}else if(inputType.contains("godan verb with su ending")) {
			inputWord = String.format("%1$ssuru, %1$sshimasu, %1$sshimasen, %1$sshinai, %1$sshita, %1$sshimashita, %1$sshinakatta, %1$sshimasen deshita", inputWord);
			return inputWord;
		}else if(inputType.contains("godan verb with tsu ending")) {
			inputWord = String.format("%1$ssuru, %1$sshimasu, %1$sshimasen, %1$sshinai, %1$sshita, %1$sshimashita, %1$sshinakatta, %1$sshimasen deshita", inputWord);
			return inputWord;
		}else if(inputType.contains("godan verb with zu ending")) {
			inputWord = String.format("%1$ssuru, %1$sshimasu, %1$sshimasen, %1$sshinai, %1$sshita, %1$sshimashita, %1$sshinakatta, %1$sshimasen deshita", inputWord);
			return inputWord;
		}else if(inputType.contains("suru verb - irregular")) {
			inputWord = String.format("%1$ssuru, %1$sshimasu, %1$sshimasen, %1$sshinai, %1$sshita, %1$sshimashita, %1$sshinakatta, %1$sshimasen deshita", inputWord);
			return inputWord;
		}else{
			return "noun";
		}
	}
	public static String pronunciation(String spnTemp) {
		String spnWord = spnTemp;
		String outWord = "";
		for(int i = 0; i != spnWord.length(); i++) {
			if(spnWord.charAt(i) == 'あ') {
				outWord = outWord +"a";
			}else if(spnWord.charAt(i) == 'い'){
				outWord = outWord +'i';
			}else if(spnWord.charAt(i) == 'う'){
				outWord = outWord +'u';
			}else if(spnWord.charAt(i) == 'え'){
				outWord = outWord +'e';
			}else if(spnWord.charAt(i) == 'お'){
				outWord = outWord +'o';
			}else if(spnWord.charAt(i) == 'か'){
				outWord = outWord + "ka";
			}else if(spnWord.charAt(i) == 'き'){
				outWord = outWord +"ki";
			}else if(spnWord.charAt(i) == 'く'){
				outWord = outWord +"ku";
			}else if(spnWord.charAt(i) == 'け'){
				outWord = outWord +"ke";
			}else if(spnWord.charAt(i) == 'こ'){
				outWord = outWord +"ko";
			}else if(spnWord.charAt(i) == 'さ'){
				outWord = outWord +"sa";
			}else if(spnWord.charAt(i) == 'し'){
				outWord = outWord +"shi";
			}else if(spnWord.charAt(i) == 'す'){
				outWord = outWord +"su";
			}else if(spnWord.charAt(i) == 'せ'){
				outWord = outWord +"se";
			}else if(spnWord.charAt(i) == 'そ'){
				outWord = outWord +"so";
			}else if(spnWord.charAt(i) == 'た'){
				outWord = outWord +"ta";
			}else if(spnWord.charAt(i) == 'ち'){
				outWord = outWord +"chi";
			}else if(spnWord.charAt(i) == 'つ'){
				outWord = outWord +"tsu";
			}else if(spnWord.charAt(i) == 'て'){
				outWord = outWord +"te";
			}else if(spnWord.charAt(i) == 'と'){
				outWord = outWord +"to";
			}else if(spnWord.charAt(i) == 'な'){
				outWord = outWord +"na";
			}else if(spnWord.charAt(i) == 'に'){
				outWord = outWord +"ni";
			}else if(spnWord.charAt(i) == 'ぬ'){
				outWord = outWord +"nu";
			}else if(spnWord.charAt(i) == 'ね'){
				outWord = outWord +"ne";
			}else if(spnWord.charAt(i) == 'の'){
				outWord = outWord +"no";
			}else if(spnWord.charAt(i) == 'は'){
				outWord = outWord +"ha";
			}else if(spnWord.charAt(i) == 'ひ'){
				outWord = outWord +"hi";
			}else if(spnWord.charAt(i) == 'ふ'){
				outWord = outWord +"fu";
			}else if(spnWord.charAt(i) == 'へ'){
				outWord = outWord +"he";
			}else if(spnWord.charAt(i) == 'ほ'){
				outWord = outWord +"ho";
			}else if(spnWord.charAt(i) == 'ま'){
				outWord = outWord +"ma";
			}else if(spnWord.charAt(i) == 'み'){
				outWord = outWord +"mi";
			}else if(spnWord.charAt(i) == 'む'){
				outWord = outWord +"mu";
			}else if(spnWord.charAt(i) == 'め'){
				outWord = outWord +"me";
			}else if(spnWord.charAt(i) == 'も'){
				outWord = outWord +"mo";
			}else if(spnWord.charAt(i) == 'や'){
				outWord = outWord +"ya";
			}else if(spnWord.charAt(i) == 'ゆ'){
				outWord = outWord +"yu";
			}else if(spnWord.charAt(i) == 'よ'){
				outWord = outWord +"yo";
			}else if(spnWord.charAt(i) == 'ら'){
				outWord = outWord +"ra";
			}else if(spnWord.charAt(i) == 'り'){
				outWord = outWord +"ri";
			}else if(spnWord.charAt(i) == 'る'){
				outWord = outWord +"ru";
			}else if(spnWord.charAt(i) == 'れ'){
				outWord = outWord +"re";
			}else if(spnWord.charAt(i) == 'ろ'){
				outWord = outWord +"ro";
			}else if(spnWord.charAt(i) == 'わ'){
				outWord = outWord +"wa";
			}else if(spnWord.charAt(i) == 'ゐ'){
				outWord = outWord +"wi";
			}else if(spnWord.charAt(i) == 'ゑ'){
				outWord = outWord +"we";
			}else if(spnWord.charAt(i) == 'を'){
				outWord = outWord +"o";
			}else if(spnWord.charAt(i) == 'が'){
				outWord = outWord +"ga";
			}else if(spnWord.charAt(i) == 'ぎ'){
				outWord = outWord +"gi";
			}else if(spnWord.charAt(i) == 'ぐ'){
				outWord = outWord +"gu";
			}else if(spnWord.charAt(i) == 'げ'){
				outWord = outWord +"ge";
			}else if(spnWord.charAt(i) == 'ご'){
				outWord = outWord +"go";
			}else if(spnWord.charAt(i) == 'ざ'){
				outWord = outWord +"za";
			}else if(spnWord.charAt(i) == 'じ'){
				outWord = outWord +"ji";
			}else if(spnWord.charAt(i) == 'ず'){
				outWord = outWord +"zu";
			}else if(spnWord.charAt(i) == 'ぜ'){
				outWord = outWord +"ze";
			}else if(spnWord.charAt(i) == 'ぞ'){
				outWord = outWord +"zo";
			}else if(spnWord.charAt(i) == 'だ'){
				outWord = outWord +"da";
			}else if(spnWord.charAt(i) == 'ぢ'){
				outWord = outWord +"dji";
			}else if(spnWord.charAt(i) == 'づ'){
				outWord = outWord +"dzu";
			}else if(spnWord.charAt(i) == 'で'){
				outWord = outWord +"de";
			}else if(spnWord.charAt(i) == 'ど'){
				outWord = outWord +"do";
			}else if(spnWord.charAt(i) == 'ば'){
				outWord = outWord +"ba";
			}else if(spnWord.charAt(i) == 'び'){
				outWord = outWord +"bi";
			}else if(spnWord.charAt(i) == 'ぶ'){
				outWord = outWord +"bu";
			}else if(spnWord.charAt(i) == 'べ'){
				outWord = outWord +"be";
			}else if(spnWord.charAt(i) == 'ぼ'){
				outWord = outWord +"bo";
			}else if(spnWord.charAt(i) == 'ぱ'){
				outWord = outWord +"pa";
			}else if(spnWord.charAt(i) == 'ぴ'){
				outWord = outWord +"pi";
			}else if(spnWord.charAt(i) == 'ぷ'){
				outWord = outWord +"pu";
			}else if(spnWord.charAt(i) == 'ぺ'){
				outWord = outWord +"pe";
			}else if(spnWord.charAt(i) == 'ぽ'){
				outWord = outWord +"po";
			}else if(spnWord.charAt(i) == 'ん') {
				outWord = outWord +"n";
			}else if(spnWord.charAt(i) == 'き' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"kya";
			}else if(spnWord.charAt(i) == 'し' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"sha";
			}else if(spnWord.charAt(i) == 'ち' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"cha";
			}else if(spnWord.charAt(i) == 'に' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"nya";
			}else if(spnWord.charAt(i) == 'ひ' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"hya";
			}else if(spnWord.charAt(i) == 'み' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"mya";
			}else if(spnWord.charAt(i) == 'り' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"rya";
			}else if(spnWord.charAt(i) == 'き' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"kyu";
			}else if(spnWord.charAt(i) == 'し' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"shu";
			}else if(spnWord.charAt(i) == 'ち' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"chu";
			}else if(spnWord.charAt(i) == 'に' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"nyu";
			}else if(spnWord.charAt(i) == 'ひ' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"hyu";
			}else if(spnWord.charAt(i) == 'み' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"myu";
			}else if(spnWord.charAt(i) == 'り' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"ryu";
			}else if(spnWord.charAt(i) == 'き' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"kyo";
			}else if(spnWord.charAt(i) == 'し' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"sho";
			}else if(spnWord.charAt(i) == 'ち' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"cho";
			}else if(spnWord.charAt(i) == 'に' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"nyo";
			}else if(spnWord.charAt(i) == 'ひ' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"hyo";
			}else if(spnWord.charAt(i) == 'み' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"myo";
			}else if(spnWord.charAt(i) == 'り' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"ryo";
			}else if(spnWord.charAt(i) == 'ぎ' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"gya";
			}else if(spnWord.charAt(i) == 'じ' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"ja";
			}else if(spnWord.charAt(i) == 'ぢ' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"ja";
			}else if(spnWord.charAt(i) == 'び' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"bya";
			}else if(spnWord.charAt(i) == 'ぴ' && spnWord.charAt(i+1) == 'ゃ'){
				outWord = outWord +"pya";
			}else if(spnWord.charAt(i) == 'ぎ' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"gyu";
			}else if(spnWord.charAt(i) == 'じ' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"ju";
			}else if(spnWord.charAt(i) == 'ぢ' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"ju";
			}else if(spnWord.charAt(i) == 'び' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"byu";
			}else if(spnWord.charAt(i) == 'ぴ' && spnWord.charAt(i+1) == 'ゅ'){
				outWord = outWord +"pyu";
			}else if(spnWord.charAt(i) == 'ぎ' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"gyo";
			}else if(spnWord.charAt(i) == 'じ' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"jo";
			}else if(spnWord.charAt(i) == 'ぢ' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"jo";
			}else if(spnWord.charAt(i) == 'び' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"byo";
			}else if(spnWord.charAt(i) == 'ぴ' && spnWord.charAt(i+1) == 'ょ'){
				outWord = outWord +"pyo";
			}
		}
		return outWord;
	}
	public static void populatingJisho() throws FailingHttpStatusCodeException, MalformedURLException, IOException {
		int inputValue = 10;
		String url ="https://jisho.org/search/%23common";
		int innerValue = 1;
		
		try (WebClient webClient = new WebClient(BrowserVersion.CHROME);){
			
			// webClient settings being changed to minimize features, increasing iteration speed
			webClient.getOptions().setRedirectEnabled(true);
			webClient.getOptions().setCssEnabled(false);
			webClient.getOptions().setThrowExceptionOnScriptError(false);
			webClient.getOptions().setThrowExceptionOnFailingStatusCode(false);
			webClient.getOptions().setUseInsecureSSL(false);
			webClient.getOptions().setJavaScriptEnabled(false);
			webClient.getCookieManager().setCookiesEnabled(false);	
			HtmlPage basePage = webClient.getPage(url);
			
			//The item List, corresponding to every element that has a path //*[@id=\"primary\"]/div/div, in other words what i care about
			List<DomElement> items = basePage.getByXPath("//*[@id=\"primary\"]/div/div");
			if(items.isEmpty()) {
				System.out.print("The list is empty.");
			}else {
				for(int i = 0; i < inputValue; i++) {
						try {
							//creates new word object, and elements that will be put into word
							HtmlSpan divDefinition = null;
							word wordSet = new word(null, null, null, null, null, null, null);
							int deepValue = 1;
							String spnTemp = "";
							HtmlSpan spnWord = null;
							HtmlAnchor anchor = basePage.getFirstByXPath("//*[@id=\"primary\"]/div/div["+ innerValue +"]/a");
							HtmlPage dictPage = anchor.click();
							List<DomElement> inItems = dictPage.getByXPath("//*[@id=\"page_container\"]/div/div");
							for(DomElement domData : inItems) {
								if(domData.getFirstByXPath("//span[@class='meaning-abstract']") != null) {
									divDefinition = domData.getFirstByXPath("//span[@class='meaning-abstract']");
								}
								else {
									divDefinition = domData.getFirstByXPath("//span[@class='meaning-meaning']");
								}
								DomElement divElements = domData.getFirstByXPath("//*[@id=\"page_container\"]/div/div/article/div/div[2]/div/div[1]");
								HtmlSpan divMean = domData.getFirstByXPath("//*[@id=\"page_container\"]/div/div/article/div/div[2]/div/div[2]/div/span[2]");
								do{
									spnWord = domData.getFirstByXPath("//*[@id=\"page_container\"]/div/div/article/div/div[1]/div[1]/div/span[1]/span["+ deepValue +"]");
									spnTemp = spnTemp + spnWord.asText();
									deepValue++;
								}while(domData.getFirstByXPath("//*[@id=\"page_container\"]/div/div/article/div/div[1]/div[1]/div/span[1]/span["+ deepValue +"]") != null);
							HtmlSpan spnKanji = domData.getFirstByXPath("//*[@id=\"page_container\"]/div/div/article/div/div[1]/div[1]/div/span[2]");
							// Grammatical corrections, not paired down to increase readability
							String divMeanOut = null;
							String divDefinitionOut = null;
							if(divMean.asText().contains(";")) {
								divMeanOut = divMean.asText().substring(0, divMean.asText().indexOf(';'));
							}else {
								divMeanOut = divMean.asText();
							}
							if(divDefinition.asText().contains(".")){
								divDefinitionOut = divDefinition.asText().substring(0, divDefinition.asText().indexOf('.') + 1);
							}else {
								divDefinitionOut = divDefinition.asText();
							}
							String spnPron = pronunciation(spnTemp);
							String divElementsOut = divElements.asText().toLowerCase();
							String conj = conjugator(divElementsOut, spnPron);
							// Defines all fields from the word value except conjugation
							wordSet.setVerbType(divElementsOut);
							wordSet.setDefinition(divDefinitionOut);
							wordSet.setEngWord(divMeanOut);
							wordSet.setJapWord(spnTemp);
							wordSet.setPron(spnPron);
							wordSet.setKanji(spnKanji.asText());
							wordSet.setConj(conj);
							words.put(divMeanOut, wordSet);
							// increases the innerValue loop variable to move onto the next html LI element
							innerValue++;
							}
						// Catches a guaranteed null pointer exception and fixes by changing inner to 1 and outer up 1, to move on to the next UL
						}catch(NullPointerException e) {
							innerValue++;
						// At end of loop, removes key that comes up as empty,
						}finally {
						if(innerValue == 20) {
							innerValue = 1;
							HtmlAnchor anchor = basePage.getFirstByXPath("//*[@id=\"primary\"]/div/a");
							basePage = anchor.click();
							items = basePage.getByXPath("//*[@id=\"primary\"]/div/div");
						}
					}
				}
			}
		}
	}
}
