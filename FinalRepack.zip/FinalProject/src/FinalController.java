import java.io.IOException;
import java.net.MalformedURLException;

import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;

import javafx.animation.Animation.Status;
import javafx.application.Platform;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.ScaleTransition;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

public class FinalController {
	
	TranslateTransition titleTransition = new TranslateTransition();
	TranslateTransition titleTransitionPT2 = new TranslateTransition();
	TranslateTransition leaveTitle = new TranslateTransition();
	ScaleTransition endTransition = new ScaleTransition();
	
    @FXML
    private VBox displayMenu;
    
    @FXML
    private TextArea displayOut;
    
    @FXML
    private VBox removeMenu;

    @FXML
    private TextField removeInput;

    @FXML
    private TextArea removeOut;

    @FXML
    private VBox insertMenu;

    @FXML
    private TextField engWord;

    @FXML
    private TextField japWord;

    @FXML
    private TextField def;

    @FXML
    private TextField verbType;

    @FXML
    private TextField conj;

    @FXML
    private TextField pron;

    @FXML
    private TextField kanji;

    @FXML
    private VBox searchMenu;

    @FXML
    private TextField searchInput;

    @FXML
    private TextArea outText;

    @FXML
    private HBox mainMenu;

    @FXML
    private Button displayButton;

    @FXML
    private Button insertButton;

    @FXML
    private Button quitButton;

    @FXML
    private Button searchButton;

    @FXML
    private Button removeButton;

    @FXML
    private StackPane menuGraphics;

    @FXML
    private Rectangle flag;

    @FXML
    private VBox SmartLibBox;

    @FXML
    private VBox textBox;

    @FXML
    private Rectangle transEffect;

    @FXML
    private Button WelcomeToTitle;

    @FXML
    void mainMenu(ActionEvent event) {
    	endTransition.setNode(transEffect);
		endTransition.setToY(200);
		endTransition.setDuration(Duration.seconds(1));
		endTransition.setDelay(Duration.seconds(0));
		endTransition.setCycleCount(1);
		endTransition.setAutoReverse(true);
    	endTransition.play();
    	endTransition.setOnFinished(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				endTransition.setToY(0);
				endTransition.play();
				mainMenu.setVisible(true);
				menuGraphics.setVisible(true);
				searchMenu.setVisible(false);
				insertMenu.setVisible(false);
				removeMenu.setVisible(false);
				displayMenu.setVisible(false);
				endTransition.setOnFinished(null);
			}
		});
    }
    
    @FXML
    void Quit(ActionEvent event) {
    	Platform.exit();
    }
    
    @FXML
    void DisplayStart(ActionEvent event) {
    	endTransition.setNode(transEffect);
		endTransition.setToY(200);
		endTransition.setDuration(Duration.seconds(1));
		endTransition.setDelay(Duration.seconds(0));
		endTransition.setCycleCount(1);
		endTransition.setAutoReverse(true);
    	endTransition.play();
    	endTransition.setOnFinished(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				endTransition.setToY(0);
				endTransition.play();
				mainMenu.setVisible(false);
				menuGraphics.setVisible(false);
				displayMenu.setVisible(true);
				endTransition.setOnFinished(null);
			}
		});
    }
    
    @FXML
    void displayMethod(ActionEvent event) {
    	displayOut.setText(FinalProject.displayAll().replace("{", "").replace("}", ""));
    }
    
    @FXML
    void InsertStart(ActionEvent event) {
    	endTransition.setNode(transEffect);
		endTransition.setToY(200);
		endTransition.setDuration(Duration.seconds(1));
		endTransition.setDelay(Duration.seconds(0));
		endTransition.setCycleCount(1);
		endTransition.setAutoReverse(true);
    	endTransition.play();
    	endTransition.setOnFinished(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				endTransition.setToY(0);
				endTransition.play();
				mainMenu.setVisible(false);
				menuGraphics.setVisible(false);
				insertMenu.setVisible(true);
				endTransition.setOnFinished(null);
			}
		});
    }
    @FXML
    void InsertMethod(ActionEvent event) {
    	FinalProject.insertion(engWord.getText(), def.getText(), japWord.getText(), verbType.getText(), conj.getText(), pron.getText(), kanji.getText());
		engWord.setText("Thank you for your input!");
		def.setText("");
		japWord.setText("");
		verbType.setText("");
		conj.setText("");
		pron.setText("");
		kanji.setText("");
    }

    @FXML
    void RemoveStart(ActionEvent event) {
    	endTransition.setNode(transEffect);
		endTransition.setToY(200);
		endTransition.setDuration(Duration.seconds(1));
		endTransition.setDelay(Duration.seconds(0));
		endTransition.setCycleCount(1);
		endTransition.setAutoReverse(true);
    	endTransition.play();
    	endTransition.setOnFinished(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				endTransition.setToY(0);
				endTransition.play();
				mainMenu.setVisible(false);
				menuGraphics.setVisible(false);
				removeMenu.setVisible(true);
				endTransition.setOnFinished(null);
			}
		});
    }
    @FXML
    void removeMethod(ActionEvent event) {
    	removeOut.setText(FinalProject.deletion(removeInput.getText()));
    }
    @FXML
    void SearchStart(ActionEvent event) {
    	endTransition.setNode(transEffect);
		endTransition.setToY(200);
		endTransition.setDuration(Duration.seconds(1));
		endTransition.setDelay(Duration.seconds(0));
		endTransition.setCycleCount(1);
		endTransition.setAutoReverse(true);
    	endTransition.play();
    	endTransition.setOnFinished(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				endTransition.setToY(0);
				endTransition.play();
				mainMenu.setVisible(false);
				menuGraphics.setVisible(false);
				searchMenu.setVisible(true);
				endTransition.setOnFinished(null);
			}
		});
    }
    @FXML
    void searchMethod(ActionEvent event) {
    	outText.setText(FinalProject.search(searchInput.getText()));
    }
    @FXML
    void initialize(ActionEvent event) {
    	try {
			FinalProject.populatingJisho();
		} catch (FailingHttpStatusCodeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	endTransition.setNode(transEffect);
		endTransition.setToY(200);
		endTransition.setDuration(Duration.seconds(1));
		endTransition.setDelay(Duration.seconds(3));
		endTransition.setCycleCount(1);
		endTransition.setAutoReverse(true);
		titleTransition.setNode(textBox);
    	titleTransition.setDuration(Duration.seconds(1));
		titleTransition.setToY(1000);
		titleTransitionPT2.setNode(SmartLibBox);
		titleTransitionPT2.setToY(300);
		titleTransitionPT2.setDuration(Duration.seconds(1));
		titleTransition.play();
		titleTransitionPT2.play();
		endTransition.play();
		WelcomeToTitle.setVisible(false);
		endTransition.setOnFinished(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				endTransition.setDelay(Duration.seconds(0));
				endTransition.setToY(0);
				endTransition.play();
				textBox.setVisible(false);
				flag.setVisible(false);
				flag.setX(2000);
				flag.setY(2000);
				SmartLibBox.setVisible(false);
				endTransition.setOnFinished(null);
			}
		});
		event.consume();
    }

}
