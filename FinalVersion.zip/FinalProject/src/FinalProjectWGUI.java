

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class FinalProjectWGUI extends Application {
	/**
	 * This is the primary stage, where everything is displayed. 
	 * I dont use multiple stages in favor of transitions, to try to avoid random screen hopping or resolution issues.
	 */
	private Stage primaryStage;

	@Override
	public void start(Stage primaryStage) {
		this.primaryStage = primaryStage;
        this.primaryStage.setTitle("GUI");
       
        GUI();
	}
	/**
	 * starts the GUI by using an fxml loader and pointing to the xml file, then setting the settings of the gui to a scene, and showing the stage with the scene as root
	 */
	private void GUI() {
		try {
			FXMLLoader loader = new FXMLLoader();
	        loader.setLocation(getClass().getResource("/GUIRedo.fxml"));
			AnchorPane GUI = loader.load();
			Scene scene = new Scene(GUI);
			primaryStage.setScene(scene);
			primaryStage.setMaximized(true);
            primaryStage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		launch(args);
	}
}
