import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;

import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;

import javafx.application.Platform;
import javafx.animation.FadeTransition;
import javafx.animation.ScaleTransition;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.util.Duration;

public class FinalController {
	/**
	 * This portion is for the transition declarations, all of these are used as effectively as i could.
	 * I'm new to GUIs so it may not be as efficient as possible.
	 * The changes they undergo are represented below in methods
	 */
	TranslateTransition titleTransition = new TranslateTransition();
	TranslateTransition titleTransitionPT2 = new TranslateTransition();
	TranslateTransition leaveTitle = new TranslateTransition();
	ScaleTransition endTransition = new ScaleTransition();
	FadeTransition kanjiTransition = new FadeTransition();
	TranslateTransition moveKan = new TranslateTransition();
	/**
	 * These are the songs and effects used, pretty similar to android studio, like most of this.
	 */
	//kodo o daiko! is derived from "Free to use sounds" https://freetousesounds.bandcamp.com/track/kodo-o-daiko-japanese-drums. Thanks.
	String songName = "kodoodaiko.mp3";
	//okedo-A1 and cymbal_1 are derived from SampleSwap https://sampleswap.org/filebrowser-new.php?d=DRUMS+%28FULL+KITS%29%2FETHNIC+and+WORLD+PERCUSSION%2FJapanese+Drums%2F. Thanks.
	String effectName = "okedo.wav";
	String returnName = "cymbal.aif";
	
	Media song = new Media(new File(songName).toURI().toString());
	Media effect = new Media(new File(effectName).toURI().toString());
	Media returnEffect = new Media(new File(returnName).toURI().toString());
	
	MediaPlayer songPlayer = new MediaPlayer(song);
	MediaPlayer effectPlayer = new MediaPlayer(effect);
	MediaPlayer returnPlayer = new MediaPlayer(returnEffect);
	/**
	 * now is a long line of variables from the fxml skeleton, @ symbols for the fxml to show it as accessible to markup, allowing effects
	 */
    @FXML
    private VBox displayMenu;

    @FXML
    private TextArea displayOut;

    @FXML
    private VBox insertMenu;

    @FXML
    private TextField engWord;

    @FXML
    private TextField japWord;

    @FXML
    private TextField def;

    @FXML
    private TextField verbType;

    @FXML
    private TextField conj;

    @FXML
    private TextField pron;

    @FXML
    private TextField kanji;

    @FXML
    private VBox removeMenu;

    @FXML
    private TextField removeInput;

    @FXML
    private TextField removeOut;

    @FXML
    private VBox searchMenu;

    @FXML
    private TextField searchInput;

    @FXML
    private TextField searchInputKanji;

    @FXML
    private TextField searchInputPron;

    @FXML
    private TextField searchInputKanjiAll;
    
    @FXML
    private TextArea outText;

    @FXML
    private HBox mainMenu;

    @FXML
    private Label dispKanji;

    @FXML
    private Button displayButton;

    @FXML
    private Label insKanji;

    @FXML
    private Button insertButton;

    @FXML
    private Label quitKanji;

    @FXML
    private Button quitButton;

    @FXML
    private Label searchKanji;

    @FXML
    private Button searchButton;

    @FXML
    private Label remKanji;

    @FXML
    private Button removeButton;

    @FXML
    private ToggleGroup Volume;

    @FXML
    private StackPane menuGraphics;

    @FXML
    private Rectangle flag;

    @FXML
    private VBox SmartLibBox;

    @FXML
    private VBox textBox;

    @FXML
    private Rectangle transEffect;

    @FXML
    private Button WelcomeToTitle;

    @FXML
    private Text hajime;
    /**
	 * here begins the methods beware all ye who enter
	 * every method with an event handler isnt compressed into a single method because each handle is different and i cant really change that effectively between them
	 * its possible, pretty easy too, but its sloppy in effect. the code looks nicer though.
	 * this menu is the main menu, it takes you to the main menu when you press the main menu button.
	 */
    @FXML
    void mainMenu(ActionEvent event) {
    	returnPlayer.play();
    	endTransition.setNode(transEffect);
		endTransition.setToY(200);
		endTransition.setDuration(Duration.seconds(1));
		endTransition.setDelay(Duration.seconds(0));
		endTransition.setCycleCount(1);
		endTransition.setAutoReverse(true);
    	endTransition.play();
    	endTransition.setOnFinished(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				endTransition.setToY(0);
				endTransition.play();
				mainMenu.setVisible(true);
				menuGraphics.setVisible(true);
				searchMenu.setVisible(false);
				insertMenu.setVisible(false);
				removeMenu.setVisible(false);
				displayMenu.setVisible(false);
				endTransition.setOnFinished(null);
			}
		});
    }
    /**
	 * This is me compressing things because it looks nicer and showing the differences.
	 * if I've run the code I've pointed it out, if not then pretty much doing it this way instead of per element makes each transition stop the other transition from working
	 * i mostly did it this way to show that i didnt just see one way it worked and used it for everything, instead i saw two ways and used them for everything
	 */
    void show() {
    	kanjiTransition.stop();
    	kanjiTransition.setDuration(Duration.seconds(3));
    	kanjiTransition.setToValue(1);
    	kanjiTransition.play();
    }
    void notShow() {
    	kanjiTransition.stop();
    	kanjiTransition.setDuration(Duration.seconds(2));
    	kanjiTransition.setToValue(0);
    	kanjiTransition.play();

    }
    /**
	 * all of these methods are for buttons, each is pretty self explanatory and shouldnt need big docs for each.
	 * the end ones end the animations for each seperate label, dispKanji in this case
	 * the start ones start them up.
	 */
    @FXML
    void dispHoverEnd(MouseEvent event) {
    	kanjiTransition.setNode(dispKanji);
    	notShow();
    }

    @FXML
    void dispHoverStart(MouseEvent event) {
    	kanjiTransition.setNode(dispKanji);
    	show();
    }
    
    @FXML
    void quitHoverEnd(MouseEvent event) {
    	kanjiTransition.setNode(quitKanji);
    	notShow();
    }

    @FXML
    void quitHoverStart(MouseEvent event) {
    	kanjiTransition.setNode(quitKanji);
    	show();
    }
    
    @FXML
    void remHoverEnd(MouseEvent event) {
    	kanjiTransition.setNode(remKanji);
    	notShow();
    }

    @FXML
    void remHoverStart(MouseEvent event) {
    	kanjiTransition.setNode(remKanji);
    	show();
    }
    
    @FXML
    void searchHoverEnd(MouseEvent event) {
    	kanjiTransition.setNode(searchKanji);
    	notShow();
    }

    @FXML
    void searchHoverStart(MouseEvent event) {
    	kanjiTransition.setNode(searchKanji);
    	show();
    }
    
    @FXML
    void insHoverEnd(MouseEvent event) {
    	kanjiTransition.setNode(insKanji);
    	notShow();
    }

    @FXML
    void insHoverStart(MouseEvent event) {
    	kanjiTransition.setNode(insKanji);
    	show();
    }
    /**
	 * This is the first real method, it exits the program
	 */
    @FXML
    void Quit(ActionEvent event) {
    	Platform.exit();
    }
    /**
	 * This is starts sound upon pressing the sound on button
	 */
    @FXML
    void soundStart(ActionEvent event) {
    	songPlayer.setMute(false);
    	effectPlayer.setMute(false);
    	returnPlayer.setMute(false);
    }
    /**
	 * This does the opposite to the start one
	 */
    @FXML
    void soundStop(ActionEvent event) {
    	songPlayer.setMute(true);
    	effectPlayer.setMute(true);
    	returnPlayer.setMute(true);
    }
    /**
	 * this is upon wanting to go to the display all menu, it transits over
	 */
    @FXML
    void DisplayStart(ActionEvent event) {
    	effectPlayer.play();
    	endTransition.setNode(transEffect);
		endTransition.setToY(200);
		endTransition.setDuration(Duration.seconds(1));
		endTransition.setDelay(Duration.seconds(0));
		endTransition.setCycleCount(1);
		endTransition.setAutoReverse(true);
    	endTransition.play();
    	endTransition.setOnFinished(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				endTransition.setToY(0);
				endTransition.play();
				mainMenu.setVisible(false);
				menuGraphics.setVisible(false);
				displayMenu.setVisible(true);
				endTransition.setOnFinished(null);
			}
		});
    }
    /**
	 * upon pressing display all it goes to the finalproject display method but sends the text to the menu
	 * similar to android studio set text
	 */
    @FXML
    void displayMethod(ActionEvent event) {
    	displayOut.setText(FinalProject.displayAll().replace("{", "").replace("}", ""));
    }
    /**
	 * this starts the insert menu
	 */
    @FXML
    void InsertStart(ActionEvent event) {
    	effectPlayer.play();
    	endTransition.setNode(transEffect);
		endTransition.setToY(200);
		endTransition.setDuration(Duration.seconds(1));
		endTransition.setDelay(Duration.seconds(0));
		endTransition.setCycleCount(1);
		endTransition.setAutoReverse(true);
    	endTransition.play();
    	endTransition.setOnFinished(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				endTransition.setToY(0);
				endTransition.play();
				mainMenu.setVisible(false);
				menuGraphics.setVisible(false);
				insertMenu.setVisible(true);
				endTransition.setOnFinished(null);
			}
		});
    }
    /**
	 * This does the insert method then clears all but one box, to show that it worked and allow quicker input
	 * it uses a get text, like the rest of these, to tell the user input. unlike android studio you dont need to convert from a char sequence to a string
	 */
    @FXML
    void InsertMethod(ActionEvent event) {
    	FinalProject.insertion(engWord.getText(), def.getText(), japWord.getText(), verbType.getText(), conj.getText(), pron.getText(), kanji.getText());
		engWord.setText("Thank you for your input!");
		def.setText("");
		japWord.setText("");
		verbType.setText("");
		conj.setText("");
		pron.setText("");
		kanji.setText("");
    }
    /**
	 * This starts the remove menu
	 */
    @FXML
    void RemoveStart(ActionEvent event) {
    	effectPlayer.play();
    	endTransition.setNode(transEffect);
		endTransition.setToY(200);
		endTransition.setDuration(Duration.seconds(1));
		endTransition.setDelay(Duration.seconds(0));
		endTransition.setCycleCount(1);
		endTransition.setAutoReverse(true);
    	endTransition.play();
    	endTransition.setOnFinished(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				endTransition.setToY(0);
				endTransition.play();
				mainMenu.setVisible(false);
				menuGraphics.setVisible(false);
				removeMenu.setVisible(true);
				endTransition.setOnFinished(null);
			}
		});
    }
    /**
	 * This calls the remove method from final project
	 */
    @FXML
    void removeMethod(ActionEvent event) {
    	removeOut.setText(FinalProject.deletion(removeInput.getText()));
    }
    @FXML
    void SearchStart(ActionEvent event) {
    	effectPlayer.play();
    	endTransition.setNode(transEffect);
		endTransition.setToY(200);
		endTransition.setDuration(Duration.seconds(1));
		endTransition.setDelay(Duration.seconds(0));
		endTransition.setCycleCount(1);
		endTransition.setAutoReverse(true);
    	endTransition.play();
    	endTransition.setOnFinished(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				endTransition.setToY(0);
				endTransition.play();
				mainMenu.setVisible(false);
				menuGraphics.setVisible(false);
				searchMenu.setVisible(true);
				endTransition.setOnFinished(null);
			}
		});
    }
    /**
	 * These are each of the corresponding search methods to the finalproject ones.
	 */
    @FXML
    void searchMethod(ActionEvent event) {
    	outText.setText(FinalProject.search(searchInput.getText()));
    }
    @FXML
    void searchPronMethod(ActionEvent event) {
    	outText.setText(FinalProject.searchPron(searchInputPron.getText()));
    }

    @FXML
    void searchKanjiMethod(ActionEvent event) {
    	outText.setText(FinalProject.searchKanji(searchInputKanji.getText()));
    }
    @FXML
    void searchAllKanjiMethod(ActionEvent event) {
    	outText.setText(FinalProject.searchKanjiAll(searchInputKanjiAll.getText()));
    }
    /**
	 * The most important method, on start it starts all of the important stuff and sets the music to loop
	 * it also does the intro transitions up to the main menu, and does the webscraping or reading if needed
	 */
    @FXML
    void initialize(ActionEvent event) {
    	try {
			FinalProject.populatingJisho();
			FinalProject.reader();
		} catch (FailingHttpStatusCodeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	songPlayer.setOnEndOfMedia(new Runnable() {
			@Override
			public void run() {
				songPlayer.seek(Duration.ZERO);
				
			}
    	});
    	songPlayer.play();
    	effectPlayer.setOnEndOfMedia(new Runnable() {
			@Override
			public void run() {
				effectPlayer.seek(Duration.ZERO);
				effectPlayer.pause();
			}
    	});
    	returnPlayer.setOnEndOfMedia(new Runnable() {
			@Override
			public void run() {
				returnPlayer.seek(Duration.ZERO);
				returnPlayer.pause();
			}
    	});
    	endTransition.setNode(transEffect);
		endTransition.setToY(40);
		endTransition.setDuration(Duration.seconds(1));
		endTransition.setDelay(Duration.seconds(3));
		endTransition.setCycleCount(1);
		endTransition.setAutoReverse(true);
		titleTransition.setNode(textBox);
    	titleTransition.setDuration(Duration.seconds(1));
		titleTransition.setToY(1000);
		titleTransitionPT2.setNode(SmartLibBox);
		titleTransitionPT2.setToY(300);
		titleTransitionPT2.setDuration(Duration.seconds(1));
		titleTransition.play();
		titleTransitionPT2.play();
		moveKan.setNode(hajime);
		moveKan.setToY(1050);
		moveKan.setDelay(Duration.seconds(3));
		moveKan.setDuration(Duration.millis(670));
		moveKan.play();
		endTransition.play();
		WelcomeToTitle.setVisible(false);
		endTransition.setOnFinished(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				kanjiTransition.setNode(transEffect);
				kanjiTransition.setDuration(Duration.seconds(2));
				kanjiTransition.setToValue(0);
				kanjiTransition.play();
				textBox.setVisible(false);
				flag.setVisible(false);
				flag.setX(2000);
				flag.setY(2000);
				SmartLibBox.setVisible(false);
				endTransition.setOnFinished(null);
				kanjiTransition.setOnFinished(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent event) {
						endTransition.setDuration(Duration.seconds(1));
						endTransition.setDelay(Duration.seconds(0));
						endTransition.setToY(0);
						endTransition.play();
						kanjiTransition.setOnFinished(null);
						endTransition.setOnFinished(new EventHandler<ActionEvent>() {

							@Override
							public void handle(ActionEvent event) {
								transEffect.setOpacity(1);
								hajime.setVisible(false);
								endTransition.setOnFinished(null);
							}
							
						});
					}
					
				});
			}
		});
		// this is another piece of code that im quite certain does nothing in this case, but because i use multiple event handlers in a row, i like to keep this here in case something goes wrong and an event does not end as needed.
		event.consume();
    }

}
