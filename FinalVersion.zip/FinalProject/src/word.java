    /**
	 * this is the word object class, i mostly generated getters and setters and made a simple constructor.
	 * the to string is what i did out of this, as it effects every single thing displayed in text boxes in the program
	 */
public class word {
	private String engWord;
	private String definition;
	private String jpWord;
	private String verbType;
	private String conj;
	private String pron;
	private String kanji;
	
	public word(String engWord, String definition, String jpWord, String verbType, String conj, String pron, String kanji) {
		this.jpWord = jpWord;
		this.definition = definition;
		this.engWord = engWord;
		this.verbType = verbType;
		this.conj = conj;
		this.pron = pron;
		this.kanji = kanji;
	}
	public String getJpWord() {
		return jpWord;
	}
	public void setJpWord(String jpWord) {
		this.jpWord = jpWord;
	}
	public String getKanji() {
		return kanji;
	}
	public void setKanji(String kanji) {
		this.kanji = kanji;
	}
	public String toString() {
			return engWord + " is " + kanji + "  which means " + definition + "\nThis is a " + verbType + " which conjugates to " + conj + " \nand is pronounced " + pron + " with the furigana " + jpWord + " representing the Kanji." + "\n\n ";
	}
	public String getDefinition() {
		return definition;
	}
	public void setDefinition(String definition) {
		this.definition = definition;
	}
	public String getEngWord() {
		return engWord;
	}
	public void setEngWord(String engWord) {
		this.engWord = engWord;
	}
	public String getVerbType() {
		return verbType;
	}
	public void setVerbType(String verbType) {
		this.verbType = verbType;
	}
	public String getConj() {
		return conj;
	}
	public void setConj(String conj) {
		this.conj = conj;
	}
	public String getPron() {
		return pron;
	}
	public void setPron(String pron) {
		this.pron = pron;
	}
	

}
